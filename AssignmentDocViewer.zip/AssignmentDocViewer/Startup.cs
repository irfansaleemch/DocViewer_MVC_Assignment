﻿//using Microsoft.Owin;
//using Owin;

//[assembly: OwinStartupAttribute(typeof(AssignmentDocViewer.Startup))]
namespace AssignmentDocViewer
{
    public partial class Startup
    {
        //public void Configuration(IAppBuilder app)
        public void Configuration()
        {
            //ConfigureAuth(app);
        }
    }
}
